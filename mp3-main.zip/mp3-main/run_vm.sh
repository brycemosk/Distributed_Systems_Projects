#!/bin/bash

code_folder='src/'
curr_folder_vm='~/mp3/tests/testAccountNotCreate/'
curr_folder_local=$(pwd)'/tests/testAccountNotCreate/'
servers=(A B C D E)
server_pids=()
password="<YOUR PASSWORD>"
username="<YOUR USERNAME>"

# copy config file to vm
for i in {1..7}; do
    sshpass -p ${password} scp config_vm.txt ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu:~/mp3/${code_folder}
done

#kill jobs corresponding to 2000 ports
for i in {1..7}
do
    echo "disconnect node$i"
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "kill -9 \$(pgrep -f config)"
done


# run servers
i=1
for server in ${servers[@]}; do
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp3; cd ${code_folder};
    ./server/main $server config_vm.txt > ../server_${server}.log 2>&1;
    echo $! > vm_pid.txt" &
    ((i=i+1))
done

# clear outputs on VM
for i in {6..7}; do
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp3; rm ${curr_folder_vm}output*.log" &
done

# clear outputs on local machine
rm ${curr_folder_local}*.log

# run clients
i=6
for j in {1..2}; do
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp3; cd ${code_folder};
    timeout 10 ./client/main a config_vm.txt < ${curr_folder_vm}input$j.txt > ${curr_folder_vm}output$j.log 2>&1
    echo $! > vm_pid.txt" &
    ((i=i+1))
done

sleep 20
# gather outputs
for i in {6..7}; do
    sshpass -p ${password} scp ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu:${curr_folder_vm}output*.log ${curr_folder_local}
done


#kill jobs corresponding to 2000 ports
for i in {1..7}
do
    echo "disconnect node$i"
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "kill -9 \$(lsof -t -i:2000)"
done

# compare outputs
echo "Difference between your output and expected output:"
diff ${curr_folder_local}output1.log ${curr_folder_local}expected1.txt
diff ${curr_folder_local}output2.log ${curr_folder_local}expected2.txt
