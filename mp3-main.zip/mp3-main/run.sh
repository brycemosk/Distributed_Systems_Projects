#!/bin/bash

code_folder='src/'
curr_folder=$(pwd)'/tests/testByTACheckFormat/'
servers=(A B C D E)
server_pids=()

# shutdown servers
shutdown() {
	for pid in ${server_pids[@]}; do
		kill -9 $pid
	done
}
trap shutdown EXIT

# initialize servers
cp config.txt ${code_folder}/config.txt
cd $code_folder
for server in ${servers[@]}; do
	./server/server $server config.txt > ../server_${server}.log 2>&1 &
	server_pids+=($!)
done

# run 2 tests
timeout 5  ./client/client a config.txt < ${curr_folder}input1.txt > ${curr_folder}output1.log 2>&1
timeout 5  ./client/client a config.txt < ${curr_folder}input2.txt > ${curr_folder}output2.log 2>&1
#timeout 5  ./client/client a config.txt < ${curr_folder}input3.txt > ${curr_folder}output3.log 2>&1
#timeout 5  ./client/client a config.txt < ${curr_folder}input4.txt > ${curr_folder}output4.log 2>&1
#timeout 5  ./client/client a config.txt < ${curr_folder}input5.txt > ${curr_folder}output5.log 2>&1

cd $curr_folder
echo "Difference between your output and expected output:"
diff output1.log expected1.txt
diff output2.log expected2.txt
#diff output3.log expected3.txt
#diff output4.log expected4.txt
#diff output5.log expected5.txt

shutdown