cp config_vm.txt src/config_vm.txt
rm ~/mp3/tests/$1/output*.log
cd src
./client/client a config_vm.txt < ~/mp3/tests/$1/input1.txt > ~/mp3/tests/$1/output1.log