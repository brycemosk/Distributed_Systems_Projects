kill -9 $(lsof -t -i:2000)
cp config_vm.txt src/config_vm.txt
cd src
./server/server D config_vm.txt > ../server_D.log