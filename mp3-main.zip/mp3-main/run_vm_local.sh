#!/bin/bash

code_folder='src/'
curr_folder_vm='~/mp3/tests/testAccountCreate/'
curr_folder_local=$(pwd)'/tests/testAccountCreate/'
servers=(A B C D E)
server_pids=()
password="Rachel.132639104"
username="jiaxiny7"

#run server scripts
for i in {1..5}
do
    echo "run local $i"
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp3; sh localScripts/server$i.sh" &
done

#run client scripts
for i in {6..7}
do
    echo "run local $i"
    sshpass -p ${password} ssh ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp3; sh localScripts/server$i.sh testAccountCreate" &
done

# clear outputs on local machine
rm ${curr_folder_local}*.log

sleep 20

# gather outputs
for i in {6..7}; do
    sshpass -p ${password} scp ${username}@sp22-cs425-g30-0"$i".cs.illinois.edu:${curr_folder_vm}output*.log ${curr_folder_local}
done

# compare outputs
echo "Difference between your output and expected output:"
diff ${curr_folder_local}output1.log ${curr_folder_local}expected1.txt
diff ${curr_folder_local}output2.log ${curr_folder_local}expected2.txt
