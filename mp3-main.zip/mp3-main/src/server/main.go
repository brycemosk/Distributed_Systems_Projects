package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type ServerInfo struct {
	nodeName    string
	nodeAddress string
	nodePort    string
}

type Account struct {
	accountValue int
	accountRTS   int
	accountWCTS  int
	accountLock  sync.RWMutex
}

type SafeServersConn struct {
	serversConn sync.Map
}

type SafeInt struct {
	mu  sync.RWMutex
	val int
}

type SafeIntMap struct {
	intMap sync.Map
}

func (sim *SafeIntMap) LoadOrStore(key string, safeInt *SafeInt) (*SafeInt, bool) {
	actual, loaded := sim.intMap.LoadOrStore(key, safeInt)
	return actual.(*SafeInt), loaded
}

func (sim *SafeIntMap) Store(key string, safeInt *SafeInt) {
	sim.intMap.Store(key, safeInt)
}

func (sim *SafeIntMap) Load(key string) (*SafeInt, bool) {
	val, ok := sim.intMap.Load(key)
	if ok {
		return val.(*SafeInt), ok
	} else {
		return nil, ok
	}
}

func (ssc *SafeServersConn) Load(bank string) *net.Conn {
	val, _ := ssc.serversConn.Load(bank)
	return val.(*net.Conn)
}

func (ssc *SafeServersConn) Store(bank string, conn *net.Conn) {
	ssc.serversConn.Store(bank, conn)
}

func (ssc *SafeServersConn) Range() map[string]*net.Conn {
	m := make(map[string]*net.Conn)
	ssc.serversConn.Range(func(key, value interface{}) bool {
		m[key.(string)] = value.(*net.Conn)
		return true
	})
	return m
}

func (ssc *SafeServersConn) Length() int {
	m := ssc.Range()
	return len(m)
}

type Server struct {
	serversConn        SafeServersConn
	branch             string
	accounts           sync.Map // accountName -> Account
	tentativeWrites    sync.Map // transactionID -> accountName -> valueToChangeBy
	rollbackTimestamps sync.Map // transactionID -> accountName -> valueToRollbackBy
	safeVotes          SafeIntMap
	safeClients        SafeServersConn
}

func New() *Server {
	return &Server{
		serversConn:        SafeServersConn{sync.Map{}},
		accounts:           sync.Map{},
		safeVotes:          SafeIntMap{sync.Map{}},
		tentativeWrites:    sync.Map{},
		rollbackTimestamps: sync.Map{},
		safeClients:        SafeServersConn{sync.Map{}},
	}
}

const (
	VALID    = 0
	INVALID  = 1
	NOTFOUND = 2
)

func (s *Server) broadcast(message string) {
	serversConnMap := s.serversConn.Range()
	for _, conn := range serversConnMap {
		(*conn).Write([]byte(message + "\n"))
	}
}

func (s *Server) send(message string, conn net.Conn) {
	conn.Write([]byte(message + "\n"))
}

func (s *Server) handleCoordinator(client net.Conn, transactionId string) {
	for {
		if s.serversConn.Length() == 5 {
			break
		}
	}
	reply := "OK"
	s.safeClients.serversConn.Store(transactionId, &client)
	s.send(reply, client)
	reader := bufio.NewScanner(client)
	for reader.Scan() {
		message := reader.Text()
		if strings.HasPrefix(message, "DEPOSIT") || strings.HasPrefix(message, "BALANCE") || strings.HasPrefix(message, "WITHDRAW") {
			words := strings.Split(message, " ")
			words = strings.Split(words[1], ".")
			branch := words[0]
			conn := s.serversConn.Load(branch)
			message = message + " " + transactionId + " " + s.branch
			s.send(message, *conn)
		} else if message == "ABORT" {
			s.abort(transactionId)
		} else if message == "COMMIT" {
			s.safeVotes.Store(transactionId, &SafeInt{sync.RWMutex{}, 0})
			s.broadcast("prepare " + transactionId + " " + s.branch)
		}
	}
}

func (s *Server) replyClient(transactionId string, message string) {
	client := s.safeClients.Load(transactionId)
	s.send(message, *client)
}

func (s *Server) replyClientTransaction(message string) {
	words := strings.Split(message, ":")
	transactionId := words[1]
	if len(words) == 2 {
		message = words[0]
	} else {
		message = words[2]
	}
	s.replyClient(transactionId, message)
}

func (s *Server) increaseVote(transactionId string) {
	safeVote, _ := s.safeVotes.Load(transactionId)
	safeVote.mu.Lock()
	safeVote.val += 1
	votes := safeVote.val
	safeVote.mu.Unlock()
	if votes == 5 {
		s.broadcast("commit " + transactionId)
		s.replyClient(transactionId, "COMMIT OK")
	}
}

func (s *Server) abort(transactionId string) {
	s.broadcast("abort " + transactionId)
	s.replyClient(transactionId, "ABORTED")
}

func (s *Server) abortNotFound(transactionId string) {
	s.broadcast("abort " + transactionId)
	s.replyClient(transactionId, "NOT FOUND, ABORTED")
}

//returns true if there is a lowerTransactionId which has a tentative write for accountName, else false
func (s *Server) lowerTransactionId(transactionId string, accountName string) bool {
	transactionIdINT, _ := strconv.Atoi(transactionId)
	lowerTID := false

	s.tentativeWrites.Range(func(transId, accMap interface{}) bool {
		transIdINT, _ := strconv.Atoi(transId.(string))

		//only if we find a lower transaction Id do we check if it has an entry for accountName
		if transIdINT < transactionIdINT {
			_, accountValid := accMap.(*sync.Map).Load(accountName)
			if accountValid {
				lowerTID = true
				return false
			}
		}

		return true
	})

	return lowerTID
}

func (s *Server) readAccount(transactionId string, accountName string) (int, int) {

	//load the account if it exists
	account, accountValid := s.accounts.LoadOrStore(accountName, &Account{})

	//this looks weird, but we always want to unlock the account after returning from this function.
	defer account.(*Account).accountLock.Unlock()

	TIDaccounts, TIDValid := s.tentativeWrites.Load(transactionId)
	var twValid bool
	if TIDValid == true {
		_, twValid = TIDaccounts.(*sync.Map).Load(accountName)
	}
	account.(*Account).accountLock.Lock()
	if (accountValid == false || account.(*Account).accountWCTS == 0) && (TIDValid == false || twValid == false) {
		return 0, NOTFOUND
	}
	account.(*Account).accountLock.Unlock()

	//wait until there is no longer a lower transactionId writing to this account
	lowerTransactionId := true
	for lowerTransactionId == true {
		account.(*Account).accountLock.Lock()
		lowerTransactionId = s.lowerTransactionId(transactionId, accountName)

		//only if there is a lower transactionID waiting do we unlock the account
		if lowerTransactionId == true {
			account.(*Account).accountLock.Unlock()

			//sleep for a bit to not eat up CPU time and allow lower transaction to run.
			time.Sleep(10 * time.Millisecond)
		}

	}

	transactionIdInt, _ := strconv.Atoi(transactionId)
	accountChangeVal := 0
	accountVal := 0

	//otherwise, grab the value
	accountVal = account.(*Account).accountValue

	//grab the tentative amount that the account will be changed by for this transaction so far
	TIDaccounts, TIDValid = s.tentativeWrites.Load(transactionId)
	if TIDValid == true {
		accountChange, accountChangeValid := TIDaccounts.(*sync.Map).Load(accountName)
		if accountChangeValid == true {
			accountChangeVal = accountChange.(int)
		}
	}

	//only return money, true if the value is > 0, and a higher ID has not wrote to this account. Otherwise we abort.
	money := accountVal + accountChangeVal
	if transactionIdInt > account.(*Account).accountWCTS {
		//update the accountRTS on valid read.
		account.(*Account).accountRTS = transactionIdInt
		return money, VALID
	} else {
		return money, INVALID
	}

}

//NOTE: We will handle aborting invalid writes at commit time. We need check again at commit time anyways, so might as well wait.
func (s *Server) tentativeWriteAccount(transactionId string, accountName string, money int, command string) int {
	TIDaccounts, TIDValid := s.tentativeWrites.Load(transactionId)
	var twValid bool
	if TIDValid == true {
		_, twValid = TIDaccounts.(*sync.Map).Load(accountName)
	}
	if command == "WITHDRAW" && (!TIDValid || !twValid) {
		account, accountExist := s.accounts.Load(accountName)
		if !accountExist {
			return NOTFOUND
		} else {
			account.(*Account).accountLock.Lock()
			accountNotValid := account.(*Account).accountWCTS == 0
			account.(*Account).accountLock.Unlock()
			if accountNotValid {
				return NOTFOUND
			}
		}
	}

	//create the tentative writes for a transactionID if they don't exist yet. Otherwise, read them.
	twAccounts, _ := s.tentativeWrites.LoadOrStore(transactionId, &sync.Map{})

	//create the tentative write entry for an account if it doesn't exist yet. Otherwise, load it.
	twAccountVal, twAccountValid := twAccounts.(*sync.Map).LoadOrStore(accountName, money)

	//if there already was an entry, add to it.
	if twAccountValid == true {
		twAccounts.(*sync.Map).Store(accountName, twAccountVal.(int)+money)
	}
	return VALID
}

func (s *Server) handleTransaction(message string) bool {
	words := strings.Split(message, " ")
	branchAccount := strings.Split(words[1], ".")
	accountName := branchAccount[1]
	transactionId := words[len(words)-2]
	coordinatorBranch := words[len(words)-1]
	coordinatorConn := s.serversConn.Load(coordinatorBranch)
	newMoney, _ := strconv.Atoi(words[2])

	if words[0] == "DEPOSIT" {

		//tentatively write to the account.
		s.tentativeWriteAccount(transactionId, accountName, newMoney, "DEPOSIT")

		//deposit is always valid. We wait at commit time if there is a lower transaction trying to write the same account.
		//we also abort at commit time if there is a higher committed timestamp already there.
		message = "OK:" + transactionId
		s.send(message, *coordinatorConn)
		return true

	} else if words[0] == "WITHDRAW" {

		//tentatively write the negative value of money to the account
		validWrite := s.tentativeWriteAccount(transactionId, accountName, -newMoney, "WITHDRAW")

		//Withdraw is always valid. We wait at commit time if there is a lower transaction trying to write the same account.
		//we also abort at commit time if there is a higher committed timestamp already there.
		if validWrite == VALID {
			message = "OK:" + transactionId
			s.send(message, *coordinatorConn)
			return true
		} else {
			message = "notFound " + transactionId
			s.send(message, *coordinatorConn)
			return false
		}
	} else if words[0] == "BALANCE" {

		money, validRead := s.readAccount(transactionId, accountName)
		//if a read is bad, tell the coordinator to abort. Used the same path as a voting no for this. May need add case when account not found.
		if validRead == INVALID {
			message = "no " + transactionId
			s.send(message, *coordinatorConn)
			return false
		} else if validRead == NOTFOUND {
			message = "notFound " + transactionId
			s.send(message, *coordinatorConn)
			return false
		} else {
			message = "OK:" + transactionId + ":" + words[1] + " = " + strconv.Itoa(money)
			s.send(message, *coordinatorConn)
			return true
		}
	}

	//should not get here, return error
	fmt.Println("Should not get here: handleTransaction function")
	return false
}

func (s *Server) cleanupServer(transactionId string) {
	s.tentativeWrites.Delete(transactionId)
	s.rollbackTimestamps.Delete(transactionId)
}

// TA mentioned we do NOT need to update the read timestamp of each account when printing all accounts on commit.
// This means that we can just print any random snapshot of our accounts. The below does just that.
// NOTE: It is okay to print a random snapshot because we will never have a case where the accounts are negative on commit.
// (I think that all they check for is non-negative balance)
func (s *Server) printAccounts() {

	//iterate over all accounts and only print if its value is > 0
	output := ""
	s.accounts.Range(func(k, v interface{}) bool {
		v.(*Account).accountLock.Lock()
		if v.(*Account).accountValue > 0 {
			output += k.(string) + ":" + strconv.Itoa(v.(*Account).accountValue) + ","
		}
		v.(*Account).accountLock.Unlock()
		return true
	})

	//remove the final extra comma and print
	if len(output) > 0 {
		output = output[:len(output)-1]
	}
	fmt.Print(output + "\n")
}

func (s *Server) vote(message string) {
	words := strings.Split(message, " ")
	transactionId := words[1]
	coordinatorBranch := words[2]
	coordinatorConn := s.serversConn.Load(coordinatorBranch)
	vote := true

	twAccounts, twValid := s.tentativeWrites.Load(transactionId)
	transactionIdINT, _ := strconv.Atoi(transactionId)

	//if there are any tentative writes, change the accounts timestamps if valid.
	if twValid == true {
		twAccounts.(*sync.Map).Range(func(accName, accVal interface{}) bool {

			//create account if it does not exist yet
			account, _ := s.accounts.LoadOrStore(accName.(string), &Account{})

			//this looks weird, but we always want to unlock the account after returning from this function.
			defer account.(*Account).accountLock.Unlock()

			//wait until there is no longer a lower transactionId writing to this account
			lowerTransactionId := true
			for lowerTransactionId == true {
				account.(*Account).accountLock.Lock()
				lowerTransactionId = s.lowerTransactionId(transactionId, accName.(string))

				//only if there is a lower transactionID waiting do we unlock the account
				if lowerTransactionId == true {
					account.(*Account).accountLock.Unlock()

					//sleep for a bit to not eat up CPU time and allow lower transaction to run.
					time.Sleep(10 * time.Millisecond)
				}

			}

			//if it is a valid transaction, update the WCTS but don't remove tentativeWrite entry yet until commit.
			newMoney := account.(*Account).accountValue + accVal.(int)
			if newMoney >= 0 &&
				transactionIdINT >= account.(*Account).accountRTS &&
				transactionIdINT > account.(*Account).accountWCTS {

				//load or create the rollbacks to keep track of for a given transactionID
				rollbacks, _ := s.rollbackTimestamps.LoadOrStore(transactionId, &sync.Map{})
				//add the account and it's old timestamp
				rollbacks.(*sync.Map).Store(accName.(string), account.(*Account).accountWCTS)
				account.(*Account).accountWCTS = transactionIdINT

				return true
			} else { //Otherwise, vote no.
				vote = false
				return false
			}
		})
	}

	if vote == true {
		s.send("yes "+transactionId, *coordinatorConn)
	} else {
		s.send("no "+transactionId, *coordinatorConn)
	}

}

func (s *Server) commit(transactionId string) {
	twAccounts, twValid := s.tentativeWrites.Load(transactionId)
	if twValid == true {
		twAccounts.(*sync.Map).Range(func(accName, accVal interface{}) bool {
			//load account we created in vote stage
			account, _ := s.accounts.Load(accName.(string))
			account.(*Account).accountLock.Lock()
			defer account.(*Account).accountLock.Unlock()

			//calculate the new money value of the account and put it in the account
			account.(*Account).accountValue = account.(*Account).accountValue + accVal.(int)

			return true
		})
	}
	//print out account balances
	s.printAccounts()
	//get rid of the tentative writes entry for this transaction, and also the rollback entry for this transaction
	s.cleanupServer(transactionId)

}

func (s *Server) handleAbort(transactionId string) {
	//rollback the timestamps for every account in rollbacks for this transactionId
	rollbacks, rValid := s.rollbackTimestamps.Load(transactionId)
	if rValid == true {
		rollbacks.(*sync.Map).Range(func(accName, oldTimestamp interface{}) bool {
			//load account we created in vote stage
			account, _ := s.accounts.Load(accName.(string))
			account.(*Account).accountLock.Lock()
			defer account.(*Account).accountLock.Unlock()

			//revert the timestamp to the old value
			account.(*Account).accountWCTS = oldTimestamp.(int)
			return true
		})
	}

	//get rid of the tentative writes entry for this transaction, and also the rollback entry for this transaction
	s.cleanupServer(transactionId)
}

func (s *Server) handle(conn net.Conn) {
	defer conn.Close()
	reader := bufio.NewScanner(conn)
	for reader.Scan() {

		message := reader.Text()
		//operations for coordinator
		if strings.HasPrefix(message, "BEGIN") {
			words := strings.Split(message, " ")
			transactionId := words[1]
			s.handleCoordinator(conn, transactionId)
		} else if strings.HasPrefix(message, "yes") {
			words := strings.Split(message, " ")
			transactionId := words[1]
			s.increaseVote(transactionId)
		} else if strings.HasPrefix(message, "notFound") {
			words := strings.Split(message, " ")
			transactionId := words[1]
			s.abortNotFound(transactionId)
		} else if strings.HasPrefix(message, "no") {
			words := strings.Split(message, " ")
			transactionId := words[1]
			s.abort(transactionId)
		} else if strings.HasPrefix(message, "OK") {
			s.replyClientTransaction(message)

			//operations for server
		} else if strings.HasPrefix(message, "DEPOSIT") || strings.HasPrefix(message, "BALANCE") || strings.HasPrefix(message, "WITHDRAW") {
			s.handleTransaction(message)
		} else if strings.HasPrefix(message, "abort") {
			words := strings.Split(message, " ")
			transactionId := words[1]
			s.handleAbort(transactionId)
		} else if strings.HasPrefix(message, "commit") {
			words := strings.Split(message, " ")
			transactionId := words[1]
			s.commit(transactionId)
		} else if strings.HasPrefix(message, "prepare") {
			s.vote(message)
		}
	}
}

func (s *Server) handleConnection(port string) {
	server, _ := net.Listen("tcp", ":"+port)
	for {
		conn, _ := server.Accept()
		go s.handle(conn)
	}
}

func (s *Server) connect(serverInfo ServerInfo) {
	var c net.Conn
	var e error
	for {
		c, e = net.Dial("tcp", serverInfo.nodeAddress+":"+serverInfo.nodePort)
		if e == nil { //ignore errors. Once there is no error, we have a connection.
			break
		}
	}
	defer c.Close()

	s.serversConn.Store(serverInfo.nodeName, &c)
	for {

	}
}

func getConfigInfo(configFile string) map[string]ServerInfo {
	f, _ := os.Open(configFile)
	scanner := bufio.NewScanner(f)
	defer f.Close()
	serversInfo := make(map[string]ServerInfo)
	for scanner.Scan() {
		lineArr := strings.Split(scanner.Text(), " ")
		server := ServerInfo{lineArr[0], lineArr[1], lineArr[2]}
		serversInfo[lineArr[0]] = server
	}
	return serversInfo
}

func (s *Server) getConnection(serversInfo map[string]ServerInfo) {
	for _, serverInfo := range serversInfo {
		go s.connect(serverInfo)
	}
}

func main() {
	s := New()
	args := os.Args
	branch := args[1]
	s.branch = branch
	configFile := args[2]
	serversInfo := getConfigInfo(configFile)

	go s.getConnection(serversInfo)
	go s.handleConnection(serversInfo[branch].nodePort)
	for {

	}
}
