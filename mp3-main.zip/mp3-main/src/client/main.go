package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

type Client struct {
	servers         []ServerInfo
	transactionId   string
	reply           chan int
	commands        []string
	curCommandIndex int
}

type ServerInfo struct {
	nodeName    string
	nodeAddress string
	nodePort    string
}

func New() *Client {
	return &Client{
		reply:           make(chan int),
		curCommandIndex: 0,
	}
}

func (c *Client) listenCoordinator(conn net.Conn) {
	scanner := bufio.NewScanner(conn)
	for scanner.Scan() {
		message := scanner.Text()
		fmt.Printf(message + "\n")
		c.reply <- 0
		if message == "COMMIT OK" || message == "ABORTED" || message == "NOT FOUND, ABORTED" {
			os.Exit(0)
		}
	}
}

func (c *Client) sendCommand(conn net.Conn) {
out:
	for {
		select {
		case _ = <-c.reply:
			break out
		default:
			time.Sleep(100)
		}
	}
	for {
		if c.curCommandIndex < len(c.commands) {
			break
		}
		time.Sleep(100)
	}
	command := c.commands[c.curCommandIndex]
	c.curCommandIndex += 1
	conn.Write([]byte(command + "\n"))
}

func (c *Client) runTransaction() {
	connChannel := make(chan net.Conn)
	go c.connectToCoordinator(connChannel)
	var conn net.Conn
out:
	for {
		select {
		case conn = <-connChannel:
			break out
		default:
			time.Sleep(100)
		}
	}
	message := "BEGIN " + c.transactionId
	conn.Write([]byte(message + "\n"))
	go c.listenCoordinator(conn)
	for {
		c.sendCommand(conn)
	}
}

func (c *Client) stdin() {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		message := scanner.Text()
		if message == "BEGIN" {
			go c.runTransaction()
		} else {
			command := scanner.Text()
			c.commands = append(c.commands, command)
		}
	}
}

func getConfigInfo(configFile string) (servers []ServerInfo) {
	f, _ := os.Open(configFile)
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		lineArr := strings.Split(scanner.Text(), " ")
		server := ServerInfo{lineArr[0], lineArr[1], lineArr[2]}
		servers = append(servers, server)
	}
	f.Close()
	return servers
}

func (c *Client) connectToCoordinator(connChannel chan net.Conn) {
	var conn net.Conn
	var e error
	serverIndex := rand.Intn(len(c.servers))
	server := c.servers[serverIndex]
	for {
		conn, e = net.Dial("tcp", server.nodeAddress+":"+server.nodePort)
		if e == nil { //ignore errors. Once there is no error, we have a connection.
			break
		}
	}
	defer conn.Close()
	connChannel <- conn
	for {

	}
}

func system_time() string {
	return strconv.FormatInt(time.Now().UnixNano(), 10)
}

func main() {
	c := New()
	args := os.Args
	config := args[2]
	servers := getConfigInfo(config)
	c.servers = servers
	c.transactionId = system_time()        // just system time should be enough info
	rand.Seed(time.Now().UTC().UnixNano()) //make sure it is different randomness each run
	go c.stdin()
	for {

	}
}
