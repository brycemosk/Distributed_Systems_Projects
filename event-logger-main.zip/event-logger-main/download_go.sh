for i in {1..9}
do
    echo "download go on node "$i""
    sshpass -p "<YOUR_PASSWORD>" ssh -o StrictHostKeyChecking=no <YOUR_USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "wget https://go.dev/dl/go1.17.6.linux-amd64.tar.gz; tar -C $HOME -xzf go1.17.6.linux-amd64.tar.gz; echo -e "export PATH=$HOME/go/bin:$PATH" >> ~/.bashrc;git clone https://<YOUR_USERNAME>:<YOUR_PASSWORD>@gitlab.engr.illinois.edu/brycejm2/event-logger.git  " &
done
