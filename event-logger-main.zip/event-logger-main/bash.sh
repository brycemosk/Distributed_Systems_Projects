for i in {2..9}
do
    echo "start run node "$i""
    sshpass -p "<YOUR_PASSWORD>" ssh <YOUR_USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd event-logger; make; python3 -u generator.py $<SPEED> | ./node node"$i" 172.22.94.98 <PORT> &" &
done
