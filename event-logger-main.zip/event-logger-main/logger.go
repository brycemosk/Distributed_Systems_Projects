package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

// func plotBandwidth() {
// 	byte_file, _ := os.OpenFile("bytes.log", os.O_RDONLY, 0444)

// }

// func plotTimeDif() {
// 	time_file, _ := os.OpenFile("bytes.log", os.O_RDONLY, 0444)
// }

// func plot() {
// 	plotBandwidth()
// 	plotTimeDif()
// }

func getMinimum(array []float64) float64 {
	min := float64(0)
	for i, e := range array {
		if i == 0 || e < min {
			min = e
		}
	}
	return min
}

func getMaximum(array []float64) float64 {
	max := float64(0)
	for _, e := range array {
		if e > max {
			max = e
		}
	}
	return max
}

func getMedian(array []float64) float64 {
	if len(array) == 0 {
		return 0
	}

	sort.Slice(array, func(i, j int) bool {
		return array[i] < array[j]
	})

	if len(array)%2 == 0 {
		return (array[(len(array)/2)-1] + array[(len(array)/2)]) / float64(2)
	} else {
		return array[(len(array) / 2)]
	}

}

func getPercentile(array []float64) float64 {
	if len(array) == 0 {
		return 0
	} else {

		sort.Slice(array, func(i, j int) bool {
			return array[i] < array[j]
		})

		return array[int(float64(len(array))*float64(0.9))] //90th percentile position is at length of array * 0.9 floored
	}
}

func appendBytes(entry int) {
	f, _ := os.OpenFile("bytes.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	bytes := strconv.Itoa(entry)
	f.Write([]byte(bytes + "\n"))
	f.Close()

}

func appendTime(entry string) {
	f, _ := os.OpenFile("time.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	f.Write([]byte(entry + "\n"))
	f.Close()
}

func system_time() string {
	return strconv.FormatFloat(float64(time.Now().UnixMicro())/float64(1000000), 'f', -1, 64)
}

func listen(client net.Conn, byte_channel chan int, time_channel chan float64) {
	defer client.Close()
	reader := bufio.NewReader(client)
	buf, _, _ := reader.ReadLine()
	name := string(buf)

	fmt.Printf("%s - %s connected\n", system_time(), name)

	for {
		buf, _, _ = reader.ReadLine()
		cur_string := strings.Split(string(buf), " ")
		if len(cur_string) == 2 {
			fmt.Printf("%s %s %s\n", cur_string[0], name, cur_string[1])
			byte_channel <- len(buf)
			recieved, _ := strconv.ParseFloat(system_time(), 64)
			created, _ := strconv.ParseFloat(cur_string[0], 64)
			time_channel <- (recieved - created)
		} else {
			fmt.Printf("%s - %s disconnected\n", system_time(), name)
			return
		}
	}
}

func collect_stats(byte_channel chan int, time_channel chan float64) {
	ticker := time.NewTicker(time.Second)
	bytes_in_second := 0
	delays_in_second := make([]float64, 0)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			minimum := strconv.FormatFloat(getMinimum(delays_in_second), 'f', -1, 64)
			median := strconv.FormatFloat(getMedian(delays_in_second), 'f', -1, 64)
			maximum := strconv.FormatFloat(getMaximum(delays_in_second), 'f', -1, 64)
			percentile := strconv.FormatFloat(getPercentile(delays_in_second), 'f', -1, 64)
			appendTime((minimum + " " + median + " " + maximum + " " + percentile)) // (minimum delay, median delay, maximum delay, 90th percentile)
			appendBytes(bytes_in_second)
			bytes_in_second = 0
			delays_in_second = delays_in_second[:0]
		case bytes := <-byte_channel:
			bytes_in_second += bytes
		case delay := <-time_channel:
			delays_in_second = append(delays_in_second, delay)
		default:
			//do nothing. This gets around ticker.C blocking the current process.
		}
	}

}

func main() {
	// defer plot()
	args := os.Args
	fmt.Println("Starting TCP server...")
	//remove old run logs
	os.Remove("time.log")
	os.Remove("bytes.log")

	server, _ := net.Listen("tcp", ":"+args[1])
	time_channel := make(chan float64)
	byte_channel := make(chan int)
	go collect_stats(byte_channel, time_channel)
	for {
		client, _ := server.Accept()
		go listen(client, byte_channel, time_channel)
	}
}
