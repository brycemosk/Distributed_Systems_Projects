from turtle import delay
import matplotlib.pyplot as plt
import numpy as np
import os
import glob


def set_up_directory():
    import os
    if not os.path.exists('plots'):
        os.makedirs('plots')
    else:
        for f in glob.glob('plots/*'):
            os.remove(f)


def generate_single_graph(data, ylabel_name, title, file_name):
    x = np.arange(0, len(data), 1)
    y = np.array(data)
    y = y.astype(np.float)
    plt.scatter(x, y, facecolor='g')

    plt.xlabel('Time(s)')
    plt.ylabel(ylabel_name)
    plt.title(title)
    plt.grid(True)
    plt.savefig(os.path.join("plots", file_name))
    plt.clf()


def generate_bandwidth_graph():
    with open('bytes.log') as f:
        bandwidth_data = f.readlines()
    bandwidth_data = [float(item.rstrip())/128 for item in bandwidth_data[0:100]]
    generate_single_graph(bandwidth_data, 'Bandwidth(Kbps)', 'Scatter plot of bandwidth', 'bandwidth.png')


def generate_delay_graph():
    with open('time.log') as f:
        delay_data = f.readlines()
    delay_data = [line.rstrip().split(' ') for line in delay_data[0:100]]
    minimum_delay_data = np.array([float(item[0]) for item in delay_data])
    median_delay_data = np.array([float(item[1]) for item in delay_data])
    maximum_delay_data = np.array([float(item[2]) for item in delay_data])
    percentile_delay_data = np.array([float(item[3]) for item in delay_data])
    generate_single_graph(minimum_delay_data, 'Minimum delay(s)', 'Scatter plot of minimum delay', 'min_delay.png')
    generate_single_graph(median_delay_data, 'Median delay(s)', 'Scatter plot of median delay', 'median_delay.png')
    generate_single_graph(maximum_delay_data, 'Maximum delay(s)', 'Scatter plot of maximum delay', 'max_delay.png')
    generate_single_graph(percentile_delay_data, '90th percentile delay(s)', 'Scatter plot of 90th percentile delay',
                          'percentile_delay.png')

if __name__ == '__main__':
    set_up_directory()
    generate_bandwidth_graph()
    generate_delay_graph()
