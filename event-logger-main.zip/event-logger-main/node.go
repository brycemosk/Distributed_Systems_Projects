package main

import (
	"bufio"
	"net"
	"os"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	args := os.Args

	name := args[1] + "\n"
	c, _ := net.Dial("tcp", args[2]+":"+args[3])
	defer c.Close()

	c.Write([]byte(name))
	for scanner.Scan() {
		c.Write([]byte(scanner.Text() + "\n"))
	}
}
