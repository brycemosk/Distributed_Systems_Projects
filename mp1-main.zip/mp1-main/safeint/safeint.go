package safeint

import "sync"

type SafeInt struct {
	Mu  sync.Mutex
	Val int
}

func New() *SafeInt {
	return &SafeInt{
		Mu:  sync.Mutex{},
		Val: 0,
	}
}

func (si *SafeInt) Increment() int {
	si.Mu.Lock()
	defer si.Mu.Unlock()
	si.Val += 1
	return si.Val
}

func (si *SafeInt) Decrement() int {
	si.Mu.Lock()
	defer si.Mu.Unlock()
	si.Val -= 1
	return si.Val
}

func (si *SafeInt) Set(val int) {
	si.Mu.Lock()
	defer si.Mu.Unlock()
	si.Val = val
}

func (si *SafeInt) Get() int {
	si.Mu.Lock()
	defer si.Mu.Unlock()
	return si.Val
}
