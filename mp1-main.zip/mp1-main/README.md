# MP1

Event_Ordering MP for CS 425.

Helper scripts for setting up, testing, and running our code is found in the "scripts" folder. 
Files used by our nodes at runtime are found in the "node" folder.