array=( sp22-cs425-g30-01.cs.illinois.edu
sp22-cs425-g30-02.cs.illinois.edu
sp22-cs425-g30-03.cs.illinois.edu
sp22-cs425-g30-04.cs.illinois.edu
sp22-cs425-g30-05.cs.illinois.edu
sp22-cs425-g30-06.cs.illinois.edu
sp22-cs425-g30-07.cs.illinois.edu
sp22-cs425-g30-08.cs.illinois.edu )
for i in "${array[@]}"
do
    sshpass -p $PASSWORD scp fake_config.txt jiaxiny7@"$i":~/mp1/node
done
