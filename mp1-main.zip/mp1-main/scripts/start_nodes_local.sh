
#THE ARGUEMENT TO THIS SCRIPT IS THE FREQUENCY OF MESSAGES. CALL THIS SCRIPT AS SUCH -> start_nodes_local.sh <speed>
#change the for loop range for the number of nodes you want to start
rm local_pids.txt
for i in {1..3}
do
    echo "starting node "$i""
    python3 -u ../node/gentx.py $1 | ../node/mp1_node node$i ../node/config.txt > ../node/events$i.txt &
    PID=$!
    echo "node$i-$PID" >> local_pids.txt
    echo "node$i-$PID"
done
 