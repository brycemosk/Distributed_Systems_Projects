

# CALL THIS SCRIPT AS SUCH -> disconnect_nodes_vm.sh
# change loop for which nodes you want to kill
for i in {1..3}
do
    echo "disconnect node$i"
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; while read -r line; do echo "Killing \$line"; pid=(\${line//-/ }); kill -9 \${pid[1]}; done < vm_pids.txt;" &
done