package main

import (
	"container/heap"
	"fmt"
	hf "mp1/helperFunctions"
	"testing"
)

/*
	Use this file to unit test various functions.
*/
func main() {
	//testConfig()
	//testBanking()
}

/*
	Tests Priority Queue
*/
func TestPriorityQueue(t *testing.T) {
	accounts := make(map[string]int)
	pq := make(hf.PriorityQueue, 0)

	item := &hf.Item{
		Message: "DEPOSIT a 50",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 1, Pid: "0"},
		Deliverable: false,
	}

	item2 := &hf.Item{
		Message: "DEPOSIT b 50",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 0, Pid: "1"},
		Deliverable: true,
	}

	item3 := &hf.Item{
		Message: "DEPOSIT c 50",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 0, Pid: "0"},
		Deliverable: false,
	}

	item4 := &hf.Item{
		Message: "TRANSFER c -> x 20",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 2, Pid: "2"},
		Deliverable: true,
	}

	item5 := &hf.Item{ //invalid transaction
		Message: "TRANSFER c -> x 40",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 1, Pid: "1"},
		Deliverable: false,
	}

	item6 := &hf.Item{
		Message: "TRANSFER c -> x 20",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 2, Pid: "3"},
		Deliverable: true,
	}

	heap.Push(&pq, item)
	heap.Push(&pq, item2)
	heap.Push(&pq, item3)

	hf.Deliver(&pq, accounts) //shouldn't deliver anything
	if pq.Len() != 3 {
		t.Fatalf("length mismatch. Len should be 3, len is: %d", pq.Len())
	}

	pq.UpdateDeliverable(item3, true)

	hf.Deliver(&pq, accounts) //should deliver first two events

	if pq.Len() != 1 {
		fmt.Printf("pq: %v", pq)
		t.Fatalf("length mismatch. Len should be 1, len is: %d", pq.Len())
	}

	pq.UpdateDeliverable(item, true)

	hf.Deliver(&pq, accounts) //should deliver last event
	if pq.Len() != 0 {
		t.Fatalf("length mismatch. Len should be 0, len is: %d", pq.Len())
	}

	heap.Push(&pq, item4)
	if pq.Len() != 1 {
		t.Fatalf("length mismatch. Len should be 1, len is: %d", pq.Len())
	}

	hf.Deliver(&pq, accounts) //should deliver last event

	if pq.Len() != 0 {
		t.Fatalf("length mismatch. Len should be 0, len is: %d", pq.Len())
	}

	hf.Deliver(&pq, accounts) //empty deliver shouldn't raise any errors

	heap.Push(&pq, item5)
	heap.Push(&pq, item6)

	hf.Deliver(&pq, accounts) //shouldn't deliver anything

	if pq.Len() != 2 {
		t.Fatalf("length mismatch. Len should be 2, len is: %d", pq.Len())
	}

	pq.UpdatePriority(item5, struct {
		SeqNumber int
		Pid       string
	}{SeqNumber: 3, Pid: "5"})

	hf.Deliver(&pq, accounts) //should deliver item6

	if pq.Len() != 1 {
		t.Fatalf("length mismatch. Len should be 1, len is: %d", pq.Len())
	}

	pq.UpdateDeliverable(item5, true)
	hf.Deliver(&pq, accounts)

	if pq.Len() != 0 {
		t.Fatalf("length mismatch. Len should be 0, len is: %d", pq.Len())
	}

}

/*
	Tests banking transactions
*/
func TestBanking(t *testing.T) {
	accounts := make(map[string]int)
	var valid string

	valid = hf.Deposit(accounts, "a", 20)
	if valid == "BAD_TRANSACTION" {
		t.Fatalf("BAD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)
	valid = hf.Deposit(accounts, "a", 30)
	if valid == "BAD_TRANSACTION" {
		t.Fatalf("BAD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)

	valid = hf.Deposit(accounts, "x", 30)
	if valid == "BAD_TRANSACTION" {
		t.Fatalf("BAD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)

	valid = hf.Transfer(accounts, "a", "c", 15)
	if valid == "BAD_TRANSACTION" {
		t.Fatalf("BAD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}

	hf.DisplayBalances(accounts)
	valid = hf.Transfer(accounts, "a", "x", 50) //invalid
	if valid == "GOOD_TRANSACTION" {
		t.Fatalf("GOOD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)
	valid = hf.Transfer(accounts, "a", "c", 50) //invalid
	if valid == "GOOD_TRANSACTION" {
		t.Fatalf("GOOD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)

	valid = hf.Transfer(accounts, "z", "p", 100) //invalid
	if valid == "GOOD_TRANSACTION" {
		t.Fatalf("GOOD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)

	valid = hf.Transfer(accounts, "a", "e", 35)
	if valid == "BAD_TRANSACTION" {
		t.Fatalf("BAD_TRANSACTION OCCURED. Current accounts: %q", accounts)
	}
	hf.DisplayBalances(accounts)

}

func TestConfig(t *testing.T) {
	nodeNames, nodeAddresses, numNodes, nodePorts := hf.GetConfigInfo("../node/config.txt")
	fmt.Println(nodeAddresses)
	fmt.Println(nodePorts)
	fmt.Println(nodeNames)
	fmt.Println(numNodes)
}
