#THE ARGUEMENT TO THIS SCRIPT IS THE FREQUENCY OF MESSAGES. CALL THIS SCRIPT AS SUCH -> start_nodes_vm.sh <speed>
# change loop for which nodes you want to start
for i in {1..3}
do
    echo "start node$i"
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; make; python3 -u gentx.py $1 | ./mp1_node node$i config.txt > events$i.txt & 
    echo node$i-\$! > vm_pids.txt; 
    echo node$i-\$!;
    sleep .1" &
done

sleep 100

# change loop for which nodes you want to kill
for i in 1
do
    echo "disconnect node$i"
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; while read -r line; do echo "Killing \$line"; pid=(\${line//-/ }); kill -9 \${pid[1]}; done < vm_pids.txt;" &
done

sleep 100

# change loop for which nodes you want to kill
for i in {2..3}
do
    echo "disconnect node$i"
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; while read -r line; do echo "Killing \$line"; pid=(\${line//-/ }); kill -9 \${pid[1]}; done < vm_pids.txt;" &
done

#gather files
for i in {1..3}
do
    echo "Gathering Files node$i"
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; sshpass -p '<YOUR-PASSWORD>' scp node'$i'_time.log <YOUR-USERNAME>@linux.ews.illinois.edu:~/cs425/mp1/node" & 
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; sshpass -p '<YOUR-PASSWORD>' scp events'$i'.txt <YOUR-USERNAME>@linux.ews.illinois.edu:~/cs425/mp1/node" & 
done