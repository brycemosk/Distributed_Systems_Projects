import matplotlib.pyplot as plt
import numpy as np
import os
import glob


def set_up_directory():
    import os
    if not os.path.exists('plots'):
        os.makedirs('plots')
    else:
        for f in glob.glob('plots/*'):
            os.remove(f)

def generate_graph():
    fulldata = []
    for i in range(1,9):
        with open('node{i}_time.log', i) as f:
            data = f.readlines()
            data = [float(item) for item in data]
            fulldata.extend(data)
    data_sorted = np.sort(data)

    p = 1. * np.arange(len(data)) / (len(data) - 1)

    plt.plot(data_sorted, p)
    plt.title("CDF 8 nodes, 5 Hz Disconnect")
    plt.xlabel('Time (s)')
    plt.ylabel('Percentile')
    plt.savefig(os.path.join("plots", "cdf_8D.png"))

if __name__ == '__main__':
    set_up_directory()
    generate_graph()
