
# change loop for which nodes you want to disconnect
for i in {2..3}
do
    echo "disconnect node$i"
    sshpass -p "<YOUR_PASSWORD>" ssh <YOUR_USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd event-logger; make; python3 -u generator.py $1 | ./node node"$i" $2 $3 &" &
done
