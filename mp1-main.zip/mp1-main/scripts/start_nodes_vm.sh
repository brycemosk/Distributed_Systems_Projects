


#THE ARGUEMENT TO THIS SCRIPT IS THE FREQUENCY OF MESSAGES. CALL THIS SCRIPT AS SUCH -> start_nodes_vm.sh <speed>
# change loop for which nodes you want to start
for i in {1..3}
do
    echo "start node$i"
    sshpass -p "<YOUR-PASSWORD>" ssh <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "cd mp1; cd node; make; python3 -u gentx.py $1 | ./mp1_node node$i config.txt > events$i.txt &
    echo node$i-\$! > vm_pids.txt; 
    echo node$i-\$! " &
done
