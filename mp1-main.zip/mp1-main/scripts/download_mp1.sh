for i in {1..9}
do
    echo "download mp1 on node "$i""
    sshpass -p "<YOUR_PASSWORD>" ssh -o StrictHostKeyChecking=no <YOUR-USERNAME>@sp22-cs425-g30-0"$i".cs.illinois.edu "git clone https://<YOUR-USERNAME>:<YOUR-PASSWORD>@gitlab.engr.illinois.edu/brycejm2/mp1.git  " &
done
 