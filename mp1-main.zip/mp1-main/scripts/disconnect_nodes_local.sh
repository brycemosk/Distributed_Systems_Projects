#!/usr/bin/env bash

#!/usr/bin/env bash


# IF YOU DON'T WANT TO KILL CERTAIN NODES, REMOVE THE LINE CORRESPONDING TO IT'S 
# NAME AND PID IN "local_pids.txt" AFTER RUNNING "start_nodes_local.sh" AND BEFORE RUNNING THIS SCRIPT.
while read -r line
do
  echo "Killing $line"
  pid=(${line//-/ })
  kill -9 ${pid[1]}  
done < local_pids.txt

# for i in {2000..2002}
# do
#   lsof -i tcp:$i | awk 'NR!=1 {print $2}' | xargs kill
# done
