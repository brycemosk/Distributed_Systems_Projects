import sys
#This script takes in the path to the files you would like to compare, and compares them.
# call as such -> python3 getdiff.py ../node/events1.txt ../node/events2.txt ../node/events2.txt

def compareFiles(file1, file2):
    lines1 = [line for line in open(file1).readlines() if line.startswith("BALANCES")]
    lines2 = [line for line in open(file2).readlines() if line.startswith("BALANCES")]
    compareLines(lines1, lines2)
    print("Finished comparing {} and {}".format(file1, file2))

def compareLines(lines1, lines2):
    for i in range(min(len(lines2), len(lines1))):
        if lines1[i] != lines2[i]:
            print(str(i) + "\n")
            print(lines1[i], " " , lines2[i])

for i in range(1, len(sys.argv)):
    for j in range(i+1, len(sys.argv)):
        compareFiles(sys.argv[i], sys.argv[j])
