package helperFunctions

import (
	"bufio"
	"container/heap"
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

/*
	Extracts all relevant information from the config file.
*/
func GetConfigInfo(configFile string) (nodeNames []string, nodeAddresses []string, numNodes int, nodePorts []string) {
	f, _ := os.Open(configFile)
	scanner := bufio.NewScanner(f)

	scanner.Scan()
	numNodes, _ = strconv.Atoi(scanner.Text())

	for scanner.Scan() {
		lineArr := strings.Split(scanner.Text(), " ")
		nodeNames = append(nodeNames, lineArr[0])
		nodeAddresses = append(nodeAddresses, lineArr[1])
		nodePorts = append(nodePorts, lineArr[2])
	}

	f.Close()
	return nodeNames, nodeAddresses, numNodes, nodePorts
}

/*
	Transfer money from one account to another. Create recieve account if it doesn't exist.
*/
func Transfer(accounts map[string]int, sendAcc string, recieveAcc string, money int) string {
	if val, ok := accounts[sendAcc]; ok && val-money >= 0 {
		accounts[sendAcc] -= money
		if _, ok := accounts[recieveAcc]; ok {
			accounts[recieveAcc] += money
		} else {
			accounts[recieveAcc] = money
		}
		return "GOOD_TRANSACTION"
	}
	return "BAD_TRANSACTION"

}

/*
	Deposit money into account. Creates account if it doesn't exist.
*/
func Deposit(accounts map[string]int, account string, money int) string {
	if _, ok := accounts[account]; ok {
		accounts[account] += money
		return "GOOD_TRANSACTION"
	}
	accounts[account] = money
	return "GOOD_TRANSACTION"
}

// TURNS OUT THERE WILL BE NO WITHDRAW TRANSACTIONS. KEEPING COMMENTED OUT FOR REFERENCE THOUGH.

// /*
// 	Withdraw money from account if account exists and won't puh the account negative.
// */
// func Withdraw(accounts map[string]int, account string, money int) string {
// 	if val, ok := accounts[account]; ok && val-money >= 0 {
// 		accounts[account] -= money
// 		return "GOOD_TRANSACTION"
// 	}
// 	return "BAD_TRANSACTION"

// }

/*
	Orders accounts alphabetically and displays the account balances.
*/
func DisplayBalances(accounts map[string]int) {
	fmt.Print("BALANCES ")

	orderedAccounts := make([]struct {
		name  string
		money int
	}, len(accounts))

	i := 0
	for account, balance := range accounts {
		orderedAccounts[i].money = balance
		orderedAccounts[i].name = account
		i++
	}

	sort.Slice(orderedAccounts, func(i2, j int) bool {
		return orderedAccounts[i2].name < orderedAccounts[j].name
	})

	for _, account := range orderedAccounts {
		if account.money != 0 {
			fmt.Printf("%s:%d ", account.name, account.money)
		}
	}

	fmt.Print("\n")

}

func Deliver(pq *PriorityQueue, accounts map[string]int) []string {
	// q := *pq
	deliveredMessages := make([]string, 0)
	for pq.Len() > 0 && pq.Peek().(*Item).Deliverable == true {
		curItem := heap.Pop(pq).(*Item)
		transaction := strings.Split(curItem.Message, " ")
		// i := 0
		// fmt.Println("***********TOP 3 QUEUE***********")
		// fmt.Printf("transaction: %s, priority: %d:%s ", curItem.Message, curItem.Priority.SeqNumber, curItem.Priority.Pid)
		// for i < pq.Len()-1 && i < 2 {
		// 	fmt.Printf("transaction: %s, priority: %d:%s ", q[i].Message, q[i].Priority.SeqNumber, q[i].Priority.Pid)
		// 	i++
		// }
		// fmt.Println(" ")
		if transaction[0] == "DEPOSIT" {
			money, _ := strconv.Atoi(transaction[2])
			Deposit(accounts, transaction[1], money)
		} else if transaction[0] == "TRANSFER" {
			money, _ := strconv.Atoi(transaction[4])
			Transfer(accounts, transaction[1], transaction[3], money)
		} else {
			//invalid transaction. IDK what we should do yet. Maybe just ignore?
		}
		DisplayBalances(accounts) // display after any transaction is processed
		trans_time := curItem.Message + "?" + system_time_str()
		deliveredMessages = append(deliveredMessages, trans_time)
	}
	return deliveredMessages
}

func system_time_str() string {
	return strconv.FormatFloat(float64(time.Now().UnixMicro())/float64(1000000), 'f', -1, 64)
}

/*
	QUEUE IMPLEMENTATION BELOW
*/

// An Item is something we manage in a priority queue.
type Item struct {
	Message     string // The value of the item; arbitrary.
	Deliverable bool   // mark used by deliver() function
	Priority    struct {
		SeqNumber int
		Pid       string
	} // The priority of the item in the queue.
	// The index is needed by update and is maintained by the heap.Interface methods.
	index int // The index of the item in the heap.
}

// A PriorityQueue implements heap.Interface and holds Items.
type PriorityQueue []*Item

//length of queue
func (pq PriorityQueue) Len() int { return len(pq) }

//for internal use with heap interface
func (pq PriorityQueue) Less(i, j int) bool {
	// We want Pop to give us the lowest, not highest, priority so we use greater than here.
	if pq[i].Priority.SeqNumber != pq[j].Priority.SeqNumber { //first compare the seqNumber
		return pq[i].Priority.SeqNumber < pq[j].Priority.SeqNumber
	} //if same seqNumber, compare the pid
	return pq[i].Priority.Pid < pq[j].Priority.Pid
}

func (PriorityQueue) GetIndex(item *Item) int {
	return item.index
}

//for internal use with heap interface.
func (pq PriorityQueue) Swap(i, j int) {
	pq[i], pq[j] = pq[j], pq[i]
	pq[i].index = i
	pq[j].index = j
}

//push onto the queue
func (pq *PriorityQueue) Push(x interface{}) {
	n := len(*pq)
	item := x.(*Item)
	item.index = n
	*pq = append(*pq, item)
}

//pop from the queue
func (pq *PriorityQueue) Pop() interface{} {
	old := *pq
	n := len(old)
	item := old[n-1]
	old[n-1] = nil  // avoid memory leak
	item.index = -1 // for safety
	*pq = old[0 : n-1]
	return item
}

//pop from the queue
func (pq *PriorityQueue) Peek() interface{} {
	q := *pq
	return q[0]
}

// update modifies the priority of an item in the queue
func (pq *PriorityQueue) UpdatePriority(item *Item, priority struct {
	SeqNumber int
	Pid       string
}) {
	item.Priority = priority
	heap.Fix(pq, item.index)
}

// update modifies the deliverable indicator of an item in the queue
func (pq *PriorityQueue) UpdateDeliverable(item *Item, deliverable bool) {
	item.Deliverable = deliverable
}

func (pq *PriorityQueue) Delete(item *Item) {
	index := item.index
	item.index = -1
	n := len(*pq)
	for i := index + 1; i < n; i++ {
		(*pq)[i-1] = (*pq)[i]
		(*pq)[i-1].index = i - 1
	}
	(*pq)[n-1] = nil
	*pq = (*pq)[:n-1]
}

func Broadcast(clients map[string]net.Conn, message string) {
	for _, c := range clients {
		c.Write([]byte(message + "\n"))
	}
}

func Unicast(clients map[string]net.Conn, nodeName string, message string) {
	c := clients[nodeName]
	c.Write([]byte(message + "\n"))
}
