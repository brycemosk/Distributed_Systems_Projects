package main

import (
	"container/heap"
	"fmt"
	hf "mp1/helperFunctions"
)

func printPq(pq hf.PriorityQueue) {
	for i := 0; i < pq.Len(); i++ {
		fmt.Printf(pq[i].Priority.Pid)
	}
	fmt.Printf("\n")
}

func main() {
	pq := make(hf.PriorityQueue, 0)
	item := &hf.Item{
		Message: "DEPOSIT a 50",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 1, Pid: "1"},
		Deliverable: false,
	}

	item2 := &hf.Item{
		Message: "DEPOSIT b 50",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 0, Pid: "2"},
		Deliverable: true,
	}

	item3 := &hf.Item{
		Message: "DEPOSIT c 50",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 0, Pid: "3"},
		Deliverable: false,
	}

	item4 := &hf.Item{
		Message: "TRANSFER c -> x 20",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 2, Pid: "4"},
		Deliverable: true,
	}

	item5 := &hf.Item{ //invalid transaction
		Message: "TRANSFER c -> x 40",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 1, Pid: "5"},
		Deliverable: false,
	}

	item6 := &hf.Item{
		Message: "TRANSFER c -> x 20",
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: 2, Pid: "6"},
		Deliverable: true,
	}

	heap.Push(&pq, item)
	heap.Push(&pq, item2)
	heap.Push(&pq, item3)
	heap.Push(&pq, item4)
	heap.Push(&pq, item5)
	heap.Push(&pq, item6)
	printPq(pq)
	pq.Delete(item3)
	printPq(pq)
	pq.Delete(item6)
	printPq(pq)
	pq.Delete(item)
	printPq(pq)
	pq.Delete(item4)
	printPq(pq)
	pq.Delete(item2)
	printPq(pq)
	pq.Delete(item5)
	printPq(pq)
}
