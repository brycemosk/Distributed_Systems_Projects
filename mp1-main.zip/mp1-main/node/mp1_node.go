package main

import (
	"bufio"
	"container/heap"
	hf "mp1/helperFunctions"
	"mp1/safeint"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type SafeClients struct {
	mu      sync.Mutex
	Clients map[string]net.Conn
}

type SafePriorityQueue struct {
	mu sync.Mutex
	pq hf.PriorityQueue
}

type MaxPriorityAndResponses struct {
	//key is the node name, ignore values of the map. Since Go does not have set, so use map instead.
	responseNodes        map[string]bool
	maxPrioritySeqNumber int
	maxPriorityPid       string
}

type SafeMessageMap struct {
	mu         sync.Mutex
	messageMap map[string]MaxPriorityAndResponses
}

type SafeAccounts struct {
	mu       sync.Mutex
	accounts map[string]int
}

//It seems that go doesn't have set structure, just ignore values of map
type SafeAgreedMessages struct {
	mu             sync.Mutex
	agreedMessages map[string]int64
}

type SafeMap struct {
	mu   sync.Mutex
	sMap map[string]float64
	wMap map[string]int
}

func (m *SafeAgreedMessages) hasMessage(message string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	_, ok := m.agreedMessages[message]
	return ok
}

func (m *SafeAgreedMessages) putMessage(message string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.agreedMessages[message] = time.Now().Unix()
}

type Node struct {
	hostName              string
	safeClients           SafeClients
	safePq                SafePriorityQueue
	safeMaxSeqNumber      *safeint.SafeInt
	safeMessageMap        SafeMessageMap
	timeGenerated         SafeMap
	timeLastNodeDelivered SafeMap
	numConnectedNodes     *safeint.SafeInt
	sid                   int
	safeAccounts          SafeAccounts
	waitConnections       sync.WaitGroup
	safeAgreedMessages    SafeAgreedMessages
	criticalSession       sync.Mutex
}

func New(hostName string) *Node {
	return &Node{
		hostName:              hostName,
		safeClients:           SafeClients{sync.Mutex{}, make(map[string]net.Conn)},
		safePq:                SafePriorityQueue{sync.Mutex{}, hf.PriorityQueue{}},
		safeMaxSeqNumber:      safeint.New(),
		safeMessageMap:        SafeMessageMap{sync.Mutex{}, make(map[string]MaxPriorityAndResponses)},
		timeGenerated:         SafeMap{sync.Mutex{}, make(map[string]float64), make(map[string]int)},
		timeLastNodeDelivered: SafeMap{sync.Mutex{}, make(map[string]float64), make(map[string]int)},
		numConnectedNodes:     safeint.New(),
		sid:                   0,
		safeAccounts:          SafeAccounts{sync.Mutex{}, make(map[string]int)},
		waitConnections:       sync.WaitGroup{},
		safeAgreedMessages:    SafeAgreedMessages{sync.Mutex{}, make(map[string]int64)},
		criticalSession:       sync.Mutex{},
	}
}

/*
	Processes a connection to this node.
*/
func (n *Node) proposePriority(receivedMessage string) {
	n.safePq.mu.Lock()
	seqNumber := n.safeMaxSeqNumber.Increment()
	info := strings.Split(receivedMessage, ":")
	message := info[2]
	item := hf.Item{
		Message:     message,
		Deliverable: false,
		Priority: struct {
			SeqNumber int
			Pid       string
		}{SeqNumber: seqNumber, Pid: n.hostName},
	}
	heap.Push(&n.safePq.pq, &item)
	n.safePq.mu.Unlock()
	n.safeClients.mu.Lock()
	clientName := info[1]
	response := strings.Join([]string{"proposed_priority", strconv.Itoa(seqNumber), n.hostName, message}, ":")
	hf.Unicast(n.safeClients.Clients, clientName, response)
	n.safeClients.mu.Unlock()
}

func (n *Node) sendAgreedMessages(message string) {
	priority := n.safeMessageMap.messageMap[message]
	remainingResponses := priority.responseNodes

	if len(remainingResponses) == 0 {
		//use hostName to indicate who sends the message
		sendMessage := strings.Join([]string{"agreed_priority", strconv.Itoa(priority.maxPrioritySeqNumber),
			priority.maxPriorityPid, message, n.hostName}, ":")
		delete(n.safeMessageMap.messageMap, message)

		n.safeClients.mu.Lock()
		hf.Broadcast(n.safeClients.Clients, sendMessage)
		n.safeClients.mu.Unlock()
	}
}

func (n *Node) receiveProposePriority(receivedMessage string) {
	info := strings.Split(receivedMessage, ":")
	seqNumber, _ := strconv.Atoi(info[1])
	pId := info[2]
	message := info[3]

	n.safeClients.mu.Lock()
	connectedNodeNames := make([]string, 0, len(n.safeClients.Clients))
	for nodeName := range n.safeClients.Clients {
		connectedNodeNames = append(connectedNodeNames, nodeName)
	}
	n.safeClients.mu.Unlock()

	n.safeMessageMap.mu.Lock()
	if val, ok := n.safeMessageMap.messageMap[message]; ok {
		delete(val.responseNodes, pId)
		if seqNumber > val.maxPrioritySeqNumber || (seqNumber == val.maxPrioritySeqNumber && pId > val.maxPriorityPid) {
			val.maxPrioritySeqNumber = seqNumber
			val.maxPriorityPid = pId
		}
		n.safeMessageMap.messageMap[message] = val
	} else {
		val.responseNodes = make(map[string]bool)
		for _, nodeName := range connectedNodeNames {
			if nodeName != pId {
				val.responseNodes[nodeName] = true
			}
		}
		val.maxPrioritySeqNumber = seqNumber
		val.maxPriorityPid = pId
		n.safeMessageMap.messageMap[message] = val
	}
	n.sendAgreedMessages(message)
	n.safeMessageMap.mu.Unlock()
}

func (n *Node) updatePq(receivedMessage string) {
	info := strings.Split(receivedMessage, ":")
	seqNumber, _ := strconv.Atoi(info[1])
	pId := info[2]
	message := info[3]
	var item *hf.Item
	n.safePq.mu.Lock()
	for i := 0; i < n.safePq.pq.Len(); i++ {
		if n.safePq.pq[i].Message == message {
			item = n.safePq.pq[i]
		}
	}
	n.safePq.pq.UpdatePriority(item, struct {
		SeqNumber int
		Pid       string
	}{SeqNumber: seqNumber, Pid: pId})
	n.safePq.pq.UpdateDeliverable(item, true)
	n.safePq.mu.Unlock()
}

func (n *Node) receiveAgreedPriority(receivedMessage string) {
	// extract the node who sends the message
	index := strings.LastIndex(receivedMessage, ":")
	senderName := receivedMessage[index+1:]
	message := receivedMessage[:index]

	info := strings.Split(message, ":")
	//avoid the case that two threads receive messages at the same time, safeAgreedMessages not update yet
	n.criticalSession.Lock()
	//first time the node receives this message
	if !n.safeAgreedMessages.hasMessage(message) {
		//initialize agreedMessages
		n.safeAgreedMessages.putMessage(message)
		//avoid broadcast from the same sender multiple times
		if senderName != n.hostName {
			n.safeClients.mu.Lock()
			hf.Broadcast(n.safeClients.Clients, message+":"+n.hostName)
			n.safeClients.mu.Unlock()
		}
		//process agreed message
		seqN, _ := strconv.Atoi(info[1])
		n.safeMaxSeqNumber.Mu.Lock()
		if seqN > n.safeMaxSeqNumber.Val {
			n.safeMaxSeqNumber.Val = seqN
		}
		n.safeMaxSeqNumber.Mu.Unlock()
		n.updatePq(message)
		n.safePq.mu.Lock()
		n.safeAccounts.mu.Lock()
		deliveredMessages := hf.Deliver(&n.safePq.pq, n.safeAccounts.accounts)
		n.safePq.mu.Unlock()
		n.safeAccounts.mu.Unlock()

		n.safeClients.mu.Lock()
		for _, transaction := range deliveredMessages {
			split_transaction := strings.Split(transaction, "+")
			clientName := strings.Split(split_transaction[2], "?")[0]
			response := strings.Join([]string{"time_delivered", transaction}, ":")
			if _, ok := n.safeClients.Clients[clientName]; ok {
				hf.Unicast(n.safeClients.Clients, clientName, response)
			}
		}
		n.safeClients.mu.Unlock()

	}
	n.criticalSession.Unlock()
}

func (n *Node) cleanUp(failedNodeName string) {
	//Get rid of client that just disconnected
	n.safeClients.mu.Lock()
	delete(n.safeClients.Clients, failedNodeName)
	n.safeClients.mu.Unlock()
	// change messageMap to not wait for proposals from disconnected nodes
	// if length equals to zero, broadcast agreed messages
	n.safeMessageMap.mu.Lock()
	for message, val := range n.safeMessageMap.messageMap {
		_, ok := val.responseNodes[failedNodeName]
		if ok {
			delete(val.responseNodes, failedNodeName)
		}
		n.safeMessageMap.messageMap[message] = val
		n.sendAgreedMessages(message)
	}
	n.safeMessageMap.mu.Unlock()
	time.Sleep(20 * time.Second)
	//remove old undeliverable messages that originated from disconnected nodes
	n.safePq.mu.Lock()
	var deleteItems []*hf.Item
	for i := 0; i < n.safePq.pq.Len(); i++ {
		initiator := strings.Split(n.safePq.pq[i].Message, "+")[2]
		if n.safePq.pq[i].Deliverable == false && initiator == failedNodeName {
			deleteItems = append(deleteItems, n.safePq.pq[i])
		}
	}
	for _, item := range deleteItems {
		heap.Remove(&n.safePq.pq, n.safePq.pq.GetIndex(item))
	}
	n.safePq.mu.Unlock()
}

func (n *Node) receiveTimeDelivered(message string, hostName string) {
	split_message := strings.Split(message, ":")
	split_transaction := strings.Split(split_message[1], "?")
	time_delivered, _ := strconv.ParseFloat(split_transaction[1], 64)

	n.timeLastNodeDelivered.mu.Lock()
	n.timeGenerated.mu.Lock()
	if val, ok := n.timeLastNodeDelivered.sMap[split_transaction[0]]; ok {
		n.timeLastNodeDelivered.wMap[split_transaction[0]] -= 1
		if time_delivered > val {
			n.timeLastNodeDelivered.sMap[split_transaction[0]] = time_delivered
		}
		if n.timeLastNodeDelivered.wMap[split_transaction[0]] == 0 {
			writeToFile(n.timeGenerated.sMap[split_transaction[0]], n.timeLastNodeDelivered.sMap[split_transaction[0]], hostName)
			delete(n.timeLastNodeDelivered.sMap, split_transaction[0])
			delete(n.timeLastNodeDelivered.wMap, split_transaction[0])
			delete(n.timeGenerated.sMap, split_transaction[0])
		}
	} else {
		n.timeLastNodeDelivered.sMap[split_transaction[0]] = time_delivered
		n.timeLastNodeDelivered.wMap[split_transaction[0]] = n.numConnectedNodes.Get() - 1
	}
	n.timeGenerated.mu.Unlock()
	n.timeLastNodeDelivered.mu.Unlock()
}

func writeToFile(timeGenerated float64, timeLastDelivered float64, hostName string) {

	f, _ := os.OpenFile(hostName+"_time.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	f.Write([]byte(strconv.FormatFloat(timeLastDelivered-timeGenerated, 'f', -1, 64) + "\n"))
	f.Close()

}

func (n *Node) handle(client net.Conn, hostName string) {
	defer client.Close()
	n.waitConnections.Wait()
	reader := bufio.NewScanner(client)
	senderName := ""

	for reader.Scan() {
		message := reader.Text()
		if strings.HasPrefix(message, "sender_node") {
			senderName = strings.Split(message, ":")[1]
		}
		if strings.HasPrefix(message, "request_priority") {
			n.proposePriority(message)
		}
		if strings.HasPrefix(message, "proposed_priority") {
			n.receiveProposePriority(message)
		}
		if strings.HasPrefix(message, "agreed_priority") {
			n.receiveAgreedPriority(message)
		}
		if strings.HasPrefix(message, "time_delivered") {
			n.receiveTimeDelivered(message, hostName)
		}
	}

	n.numConnectedNodes.Decrement()
	n.cleanUp(senderName)
}

/*
	Connect to a given node via its address and port. Probably need to send hostName so processes know which nodes are speaking.
*/
func (n *Node) connect(nodeName string, nodeAddress string, nodePort string) {

	var c net.Conn
	var e error
	for {
		c, e = net.Dial("tcp", nodeAddress+":"+nodePort)
		if e == nil { //ignore errors. Once there is no error, we have a connection.
			break
		}
	}
	defer c.Close()
	n.safeClients.mu.Lock()
	n.safeClients.Clients[nodeName] = c
	n.safeClients.mu.Unlock()
	for {

	}

}

func system_time_float() float64 {
	return float64(time.Now().UnixMicro()) / float64(1000000)
}

func (n *Node) stdin() {
	n.waitConnections.Wait()
	hf.Broadcast(n.safeClients.Clients, "sender_node:"+n.hostName)
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		stringSid := strconv.Itoa(n.sid)
		n.safeClients.mu.Lock()
		transaction := scanner.Text() + " +" + stringSid + "+" + n.hostName

		n.timeGenerated.mu.Lock()
		n.timeGenerated.sMap[transaction] = system_time_float()
		n.timeGenerated.mu.Unlock()

		message := "request_priority:" + n.hostName + ":" + transaction
		hf.Broadcast(n.safeClients.Clients, message)
		n.safeClients.mu.Unlock()
		n.sid += 1
	}

}

func (n *Node) waitForAllConnections(numNodes int) {
	for {
		n.safeClients.mu.Lock()
		//fmt.Printf("%d, %d, %d \n", len(n.safeClients.Clients), n.numConnectedNodes.Get(), numNodes)
		if numNodes <= len(n.safeClients.Clients) && numNodes <= n.numConnectedNodes.Get() { // wait until all connections are made
			n.waitConnections.Done()
			n.safeClients.mu.Unlock()
			return
		}
		n.safeClients.mu.Unlock()
	}

}

func (n *Node) cleanAgreedMessages() {
	for {
		// clean the message every 40 seconds
		time.Sleep(40 * time.Second)
		currTime := time.Now().Unix()
		oldTime := currTime - 40
		n.safeAgreedMessages.mu.Lock()
		for message, saveTime := range n.safeAgreedMessages.agreedMessages {
			if saveTime < oldTime {
				delete(n.safeAgreedMessages.agreedMessages, message)
			}
		}
		n.safeAgreedMessages.mu.Unlock()
	}
}

func main() {

	args := os.Args
	var hostPort string
	hostName := args[1]
	node := New(hostName)
	//remove old run logs
	os.Remove(hostName + "_time.log")

	nodeNames, nodeAddresses, numNodes, nodePorts := hf.GetConfigInfo(args[2])

	//connect to every node in the config file, including ourselves.
	for i := 0; i < numNodes; i++ {
		go node.connect(nodeNames[i], nodeAddresses[i], nodePorts[i])

		if nodeNames[i] == args[1] { //extract the port we should listen on depending on the identifier given.
			hostPort = nodePorts[i]
		}
	}
	//listen for connections from the other nodes.
	node.waitConnections.Add(1)
	go node.waitForAllConnections(numNodes)
	go node.stdin()
	go node.cleanAgreedMessages()
	server, _ := net.Listen("tcp", ":"+hostPort)
	for {
		client, _ := server.Accept()
		go node.handle(client, hostName)
		node.numConnectedNodes.Increment()
	}
}
